/**
 * ASK SOLUTIONS - GradientWaves Interactive WebGL 3D Wave Component
 * Vanilla JavaScript implementation inspired by @react-bits/GradientWaves
 * Powered by OGL (Minimal WebGL 2 Library)
 *
 * Raymarched 3D plasma waves with dynamic swell, turbulence, fog depth,
 * chromatic gradient coloring, grain texture, and cursor parallax interaction.
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.GradientWaves = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const hexToRgb = (hex) => {
    if (!hex) return [1, 1, 1];
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return [1, 1, 1];
    return [
      parseInt(result[1], 16) / 255,
      parseInt(result[2], 16) / 255,
      parseInt(result[3], 16) / 255
    ];
  };

  const detailToSteps = (detail) => {
    if (detail === 'low') return 40.0;
    if (detail === 'high') return 110.0;
    return 70.0; // 'medium'
  };

  const vertexShader = `#version 300 es
in vec2 position;
void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

  const fragmentShader = `#version 300 es
precision highp float;
uniform vec2 iResolution;
uniform float iTime;
uniform float uSpeed;
uniform float uAmplitude;
uniform float uWaveScale;
uniform float uWaveRatio;
uniform float uSwell;
uniform float uTurbulence;
uniform float uTilt;
uniform float uZoom;
uniform float uHeight;
uniform float uFogDepth;
uniform float uSteps;
uniform float uBrightness;
uniform float uOpacity;
uniform float uGrain;
uniform float uGrainIntensity;
uniform vec2 uMouse;
uniform float uParallax;
uniform bool uEnableMouse;
uniform vec3 uHorizonColor;
uniform vec3 uWaveColor;
uniform vec3 uCrestColor;
out vec4 fragColor;

const float MAX_DIST = 20000.0;

float hash21(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float plasma(vec3 r, vec2 freq, vec4 tc) {
  float mx = r.x + tc.x;
  mx += uSwell * sin((r.y + mx) / 20.0 + tc.y);
  float my = r.y - tc.z;
  my += uTurbulence * cos(r.x / 23.0 + tc.w);
  return r.z - (sin(mx * freq.x) * uAmplitude + sin(my * freq.y) * uAmplitude + uHeight);
}

float raymarch(vec3 pos, vec3 dir, vec2 freq, vec4 tc) {
  float dist = 0.0;
  for (int i = 0; i < 128; i++) {
    if (float(i) >= uSteps) break;
    float dscene = plasma(pos + dist * dir, freq, tc);
    if (abs(dscene) < 0.1) break;
    dist += 0.9 * dscene;
    if (!(abs(dist) < MAX_DIST)) return MAX_DIST;
  }
  return dist;
}

void main() {
  float T = iTime * uSpeed;
  vec2 freq = vec2(uWaveScale / 7.0, (uWaveScale * uWaveRatio) / 3.0);
  vec4 tc = vec4(T / 0.130, T / 0.810, T / 0.200, T / 0.710);
  float c, s;
  float vfov = (3.14159 / 2.3) / max(uZoom, 0.05);
  vec3 cam = vec3(0.0, 0.0, 30.0);
  vec2 uv = (gl_FragCoord.xy / iResolution.xy) - 0.5;
  uv.x *= iResolution.x / iResolution.y;
  uv.y *= -1.0;

  vec3 dir = vec3(0.0, 0.0, -1.0);
  float ulen = length(uv);
  float xrot = vfov * ulen;
  c = cos(xrot); s = sin(xrot);
  dir = mat3(1.0, 0.0, 0.0, 0.0, c, -s, 0.0, s, c) * dir;
  vec2 nuv = ulen > 1e-5 ? uv / ulen : vec2(1.0, 0.0);
  c = nuv.x; s = nuv.y;
  dir = mat3(c, -s, 0.0, s, c, 0.0, 0.0, 0.0, 1.0) * dir;
  c = cos(uTilt); s = sin(uTilt);
  dir = mat3(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c) * dir;

  if (uEnableMouse) {
    float yaw = (uMouse.x - 0.5) * uParallax * 0.4;
    float pitch = (uMouse.y - 0.5) * uParallax * 0.4;
    c = cos(yaw); s = sin(yaw);
    dir = mat3(c, 0.0, s, 0.0, 1.0, 0.0, -s, 0.0, c) * dir;
    c = cos(pitch); s = sin(pitch);
    dir = mat3(1.0, 0.0, 0.0, 0.0, c, -s, 0.0, s, c) * dir;
  }

  float dist = raymarch(cam, dir, freq, tc);
  vec3 pos = cam + dist * dir;

  float t = clamp(uFogDepth / max(dist, 0.001), 0.0, 1.0);
  vec3 body = mix(uWaveColor, uCrestColor, clamp(pos.z * 0.08 + 0.5, 0.0, 1.0));
  vec3 col = mix(uHorizonColor, body, t);
  col *= uBrightness;
  col = clamp(col, 0.0, 1.0);

  float alpha = clamp(t, 0.0, 1.0) * uOpacity;
  if (uGrain > 0.5) {
    float g = hash21(gl_FragCoord.xy + mod(iTime, 64.0) * 11.0);
    alpha += (g - 0.5) * uGrainIntensity;
  }
  alpha = clamp(alpha, 0.0, 1.0);
  fragColor = vec4(col * alpha, alpha);
}
`;

  const defaultOptions = {
    horizonColor: '#5227FF',
    waveColor: '#FF9FFC',
    crestColor: '#FFFFFF',
    speed: 0.4,
    amplitude: 2.5,
    waveScale: 0.6,
    waveRatio: 0.9,
    swell: 35,
    turbulence: 20,
    tilt: 1.11,
    zoom: 1.0,
    height: 5.5,
    fogDepth: 15,
    detail: 'medium',
    brightness: 1.0,
    opacity: 1.0,
    mouseInteraction: true,
    parallaxStrength: 0.5,
    grain: true,
    grainIntensity: 0.05,
    interactiveTarget: null // Element to listen for mouse moves on (defaults to container or parent)
  };

  /**
   * Create GradientWaves instance on a container element
   */
  function createGradientWaves(target, customOptions = {}) {
    const container = typeof target === 'string' ? document.querySelector(target) : target;
    if (!container) return null;

    if (!window.OGL) {
      console.error('GradientWaves: OGL library not found on window.OGL. Ensure ogl.min.js is included.');
      return null;
    }

    const { Renderer, Program, Mesh, Triangle } = window.OGL;

    // Parse options from data-attributes
    const datasetOpts = {};
    if (container.dataset.horizonColor) datasetOpts.horizonColor = container.dataset.horizonColor;
    if (container.dataset.waveColor) datasetOpts.waveColor = container.dataset.waveColor;
    if (container.dataset.crestColor) datasetOpts.crestColor = container.dataset.crestColor;
    if (container.dataset.speed) datasetOpts.speed = parseFloat(container.dataset.speed);
    if (container.dataset.amplitude) datasetOpts.amplitude = parseFloat(container.dataset.amplitude);
    if (container.dataset.waveScale) datasetOpts.waveScale = parseFloat(container.dataset.waveScale);
    if (container.dataset.waveRatio) datasetOpts.waveRatio = parseFloat(container.dataset.waveRatio);
    if (container.dataset.swell) datasetOpts.swell = parseFloat(container.dataset.swell);
    if (container.dataset.turbulence) datasetOpts.turbulence = parseFloat(container.dataset.turbulence);
    if (container.dataset.tilt) datasetOpts.tilt = parseFloat(container.dataset.tilt);
    if (container.dataset.zoom) datasetOpts.zoom = parseFloat(container.dataset.zoom);
    if (container.dataset.height) datasetOpts.height = parseFloat(container.dataset.height);
    if (container.dataset.fogDepth) datasetOpts.fogDepth = parseFloat(container.dataset.fogDepth);
    if (container.dataset.detail) datasetOpts.detail = container.dataset.detail;
    if (container.dataset.brightness) datasetOpts.brightness = parseFloat(container.dataset.brightness);
    if (container.dataset.opacity) datasetOpts.opacity = parseFloat(container.dataset.opacity);
    if (container.dataset.parallaxStrength) datasetOpts.parallaxStrength = parseFloat(container.dataset.parallaxStrength);
    if (container.dataset.grainIntensity) datasetOpts.grainIntensity = parseFloat(container.dataset.grainIntensity);

    const config = Object.assign({}, defaultOptions, datasetOpts, customOptions);

    container.classList.add('gradient-waves-container');

    // Create WebGL2 renderer
    let renderer;
    try {
      renderer = new Renderer({
        webgl: 2,
        alpha: true,
        premultipliedAlpha: true,
        antialias: false,
        dpr: Math.min(window.devicePixelRatio || 1, 2)
      });
    } catch (err) {
      console.warn('GradientWaves: WebGL 2 creation failed:', err);
      return null;
    }

    const gl = renderer.gl;
    if (!gl) {
      console.warn('GradientWaves: WebGL 2 context unavailable.');
      return null;
    }

    gl.clearColor(0, 0, 0, 0);
    const canvas = gl.canvas;
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.display = 'block';
    container.appendChild(canvas);

    const hc = hexToRgb(config.horizonColor);
    const wc = hexToRgb(config.waveColor);
    const cc = hexToRgb(config.crestColor);

    const geometry = new Triangle(gl);
    const program = new Program(gl, {
      vertex: vertexShader,
      fragment: fragmentShader,
      uniforms: {
        iTime: { value: 0 },
        iResolution: { value: new Float32Array([1, 1]) },
        uSpeed: { value: config.speed },
        uAmplitude: { value: config.amplitude },
        uWaveScale: { value: config.waveScale },
        uWaveRatio: { value: config.waveRatio },
        uSwell: { value: config.swell },
        uTurbulence: { value: config.turbulence },
        uTilt: { value: config.tilt },
        uZoom: { value: config.zoom },
        uHeight: { value: config.height },
        uFogDepth: { value: config.fogDepth },
        uSteps: { value: detailToSteps(config.detail) },
        uBrightness: { value: config.brightness },
        uOpacity: { value: config.opacity },
        uGrain: { value: config.grain ? 1.0 : 0.0 },
        uGrainIntensity: { value: config.grainIntensity },
        uMouse: { value: new Float32Array([0.5, 0.5]) },
        uParallax: { value: config.parallaxStrength },
        uEnableMouse: { value: config.mouseInteraction },
        uHorizonColor: { value: new Float32Array(hc) },
        uWaveColor: { value: new Float32Array(wc) },
        uCrestColor: { value: new Float32Array(cc) }
      }
    });

    const mesh = new Mesh(gl, { geometry, program });

    // Handle Resize
    const setSize = () => {
      const rect = container.getBoundingClientRect();
      const w = Math.max(1, Math.floor(rect.width));
      const h = Math.max(1, Math.floor(rect.height));
      renderer.setSize(w, h);
      const res = program.uniforms.iResolution.value;
      res[0] = gl.drawingBufferWidth;
      res[1] = gl.drawingBufferHeight;
      renderer.render({ scene: mesh });
    };

    const ro = new ResizeObserver(setSize);
    ro.observe(container);
    setSize();

    // Mouse Interaction
    const currentMouse = [0.5, 0.5];
    const targetMouse = [0.5, 0.5];

    // Listen on interactive target (e.g. hero section) so foreground elements don't block cursor tracking
    const mouseTarget = config.interactiveTarget || container.closest('section') || container;

    const onPointerMove = (e) => {
      const rect = mouseTarget.getBoundingClientRect();
      targetMouse[0] = (e.clientX - rect.left) / rect.width;
      targetMouse[1] = 1.0 - (e.clientY - rect.top) / rect.height;
    };

    const onPointerLeave = () => {
      targetMouse[0] = 0.5;
      targetMouse[1] = 0.5;
    };

    if (config.mouseInteraction) {
      mouseTarget.addEventListener('pointermove', onPointerMove, { passive: true });
      mouseTarget.addEventListener('pointerleave', onPointerLeave, { passive: true });
    }

    // Animation Loop
    let raf = 0;
    let isVisible = true;
    let isPageVisible = !document.hidden;
    const t0 = performance.now();

    const loop = (t) => {
      program.uniforms.iTime.value = (t - t0) * 0.001;
      const tx = config.mouseInteraction ? targetMouse[0] : 0.5;
      const ty = config.mouseInteraction ? targetMouse[1] : 0.5;
      currentMouse[0] += 0.05 * (tx - currentMouse[0]);
      currentMouse[1] += 0.05 * (ty - currentMouse[1]);
      program.uniforms.uMouse.value[0] = currentMouse[0];
      program.uniforms.uMouse.value[1] = currentMouse[1];

      renderer.render({ scene: mesh });
      raf = requestAnimationFrame(loop);
    };

    const tryStart = () => {
      if (isVisible && isPageVisible && raf === 0) {
        raf = requestAnimationFrame(loop);
      }
    };

    const tryStop = () => {
      if (raf !== 0) {
        cancelAnimationFrame(raf);
        raf = 0;
      }
    };

    // IntersectionObserver to pause when scrolled out of view
    const io = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
        if (isVisible) {
          tryStart();
        } else {
          tryStop();
        }
      },
      { threshold: 0 }
    );
    io.observe(container);

    // Tab visibility handling
    const onVisibility = () => {
      isPageVisible = !document.hidden;
      if (isPageVisible) {
        tryStart();
      } else {
        tryStop();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);

    tryStart();

    // Instance API
    const instance = {
      destroy: () => {
        tryStop();
        ro.disconnect();
        io.disconnect();
        document.removeEventListener('visibilitychange', onVisibility);
        if (config.mouseInteraction) {
          mouseTarget.removeEventListener('pointermove', onPointerMove);
          mouseTarget.removeEventListener('pointerleave', onPointerLeave);
        }
        try {
          if (canvas.parentNode === container) {
            container.removeChild(canvas);
          }
          gl.getExtension('WEBGL_lose_context')?.loseContext();
        } catch (e) {
          void e;
        }
      },
      setOptions: (newOpts) => {
        Object.assign(config, newOpts);
        const u = program.uniforms;
        if ('speed' in newOpts) u.uSpeed.value = config.speed;
        if ('amplitude' in newOpts) u.uAmplitude.value = config.amplitude;
        if ('waveScale' in newOpts) u.uWaveScale.value = config.waveScale;
        if ('waveRatio' in newOpts) u.uWaveRatio.value = config.waveRatio;
        if ('swell' in newOpts) u.uSwell.value = config.swell;
        if ('turbulence' in newOpts) u.uTurbulence.value = config.turbulence;
        if ('tilt' in newOpts) u.uTilt.value = config.tilt;
        if ('zoom' in newOpts) u.uZoom.value = config.zoom;
        if ('height' in newOpts) u.uHeight.value = config.height;
        if ('fogDepth' in newOpts) u.uFogDepth.value = config.fogDepth;
        if ('detail' in newOpts) u.uSteps.value = detailToSteps(config.detail);
        if ('brightness' in newOpts) u.uBrightness.value = config.brightness;
        if ('opacity' in newOpts) u.uOpacity.value = config.opacity;
        if ('grain' in newOpts) u.uGrain.value = config.grain ? 1.0 : 0.0;
        if ('grainIntensity' in newOpts) u.uGrainIntensity.value = config.grainIntensity;
        if ('parallaxStrength' in newOpts) u.uParallax.value = config.parallaxStrength;
        if ('mouseInteraction' in newOpts) u.uEnableMouse.value = config.mouseInteraction;

        if (newOpts.horizonColor) {
          const h = hexToRgb(newOpts.horizonColor);
          u.uHorizonColor.value.set(h);
        }
        if (newOpts.waveColor) {
          const w = hexToRgb(newOpts.waveColor);
          u.uWaveColor.value.set(w);
        }
        if (newOpts.crestColor) {
          const c = hexToRgb(newOpts.crestColor);
          u.uCrestColor.value.set(c);
        }
      }
    };

    container.gradientWaves = instance;
    return instance;
  }

  // Auto-initialize elements with .gradient-waves or #hero-gradient-waves
  function autoInit() {
    const targets = document.querySelectorAll('.gradient-waves, #hero-gradient-waves');
    targets.forEach((el) => {
      if (!el.gradientWaves) {
        createGradientWaves(el);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  createGradientWaves.initAll = autoInit;
  return createGradientWaves;
});
